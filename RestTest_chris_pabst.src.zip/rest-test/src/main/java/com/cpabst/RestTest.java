package com.cpabst;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import spark.QueryParamsMap;
import spark.Request;
import spark.Response;
import spark.Route;
import static spark.Spark.*;

public class RestTest {
    static final String ID_PARAM = ":id";
    static final String SEARCH_PARAM = "query";
    static final String NOT_FOUND_MSG_ID = "No note exists for id ";
                                        // need trailing space
    static final String NO_QUERY_TEXT = "No query text was provided";
                                        // need trailing space

    static Integer idCounter = 1;
    static final HashMap<Integer, Note> notes = new HashMap<Integer, Note>();
    static final Logger log = LoggerFactory.getLogger(com.cpabst.RestTest.class);
    static final ObjectMapper mapper = new ObjectMapper();
    
    private static String addNote(Request req, Response res) 
            throws JsonParseException, JsonMappingException, IOException {
        PostBody body = null;
        Note newNote = null;

        body = mapper.readValue(req.body(), PostBody.class);

        log.info(body.toString());

        newNote = new Note(idCounter++, body.getBody());
        notes.put(newNote.getId(), newNote);

        return mapper.writeValueAsString(newNote);
    }

    private static String allNotes(Request req, Response res) 
            throws JsonParseException, JsonMappingException, IOException {
        List<Note> noteList = new ArrayList<Note>(notes.values());

        return mapper.writeValueAsString(noteList);
    }

    private static String aNote(Request req, Response res) 
            throws JsonParseException, JsonMappingException, IOException {
        String idParam = req.params(ID_PARAM);
        Integer id = null;

        if (StringUtils.isBlank(idParam)) {
            return NOT_FOUND_MSG_ID + idParam;
        }

        id = new Integer(idParam);
        log.info("Looking for note " + idParam);
        
        if (notes.get(id) == null) {
            return NOT_FOUND_MSG_ID + idParam;
        }

        return mapper.writeValueAsString(notes.get(id));
    }

    private static String findNote(QueryParamsMap paramsMap) throws JsonProcessingException {
        String queryText = paramsMap.value(SEARCH_PARAM);
        List<Note> matchingNotes = new ArrayList<Note>();

        if (StringUtils.isBlank(queryText)) {
            return NO_QUERY_TEXT;
        }

        log.info("Looking for note text " + queryText);
        
        for (Note currNote : notes.values()) {
            if (currNote.getNote().contains(queryText)) {
                matchingNotes.add(currNote);
            }
        }

        return mapper.writeValueAsString(matchingNotes);
    }

    public static void main(String[] args) {
        post("/api/notes", "application/json", new Route() {
            
            @Override
            public Object handle(Request req, Response res) throws Exception {
                return addNote(req, res);
            }
        });

        get("/api/notes", new Route() {
            
            @Override
            public Object handle(Request req, Response res) throws Exception {
                QueryParamsMap paramsMap = req.queryMap();
                
                /* First check whether this is a text search or not. */

                if (paramsMap.hasKeys()) {
                    return findNote(paramsMap);
                }
                return allNotes(req, res);
            }
        });

        get("/api/notes/" + ID_PARAM, new Route() {
            
            @Override
            public Object handle(Request req, Response res) throws Exception {
                return aNote(req, res);
            }
        });
    }
}
