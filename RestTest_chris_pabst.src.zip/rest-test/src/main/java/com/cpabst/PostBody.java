package com.cpabst;

public class PostBody {
    private String body = null;

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    @Override
    public String toString() {
	StringBuilder builder = new StringBuilder();
	builder.append("PostBody [body=").append(body).append("]");
	return builder.toString();
    }
}
