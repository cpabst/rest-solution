package com.cpabst;

public class Note {
    private Integer id = null;
    private String note = null;

    public Note(Integer id, String note) {
	this.id = id;
	this.note = note;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public String toString() {
	StringBuilder builder = new StringBuilder();
	builder.append("Note [id=").append(id).append(", note=").append(note)
		.append("]");
	return builder.toString();
    }
}
